package com.dao;

public interface DeptDao {
    void delete();
}
