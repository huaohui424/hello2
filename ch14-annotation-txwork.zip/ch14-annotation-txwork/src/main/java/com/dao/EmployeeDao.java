package com.dao;

public interface EmployeeDao {
    void insert();
}
